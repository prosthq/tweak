@echo off
setlocal
cd /d "%~dp0"
title PTweaks - PROST Performance
echo.
echo   PTWEAKS / PROST PERFORMANCE
echo.
if not exist "runtime\node.exe" (
  echo The bundled runtime is missing.
  echo Right-click the downloaded ZIP, choose Extract All, then run this file
  echo from inside the extracted PTweaks folder.
  pause
  exit /b 1
)
if not exist "server\desktop.mjs" (
  echo PTweaks files are missing. Extract the complete ZIP and try again.
  pause
  exit /b 1
)
if not exist "dist\index.html" (
  echo PTweaks interface files are missing. Extract the complete ZIP again.
  pause
  exit /b 1
)
echo Your browser will open PTweaks on this computer.
echo Keep this window open while using the utility.
echo Right-click this launcher and choose Run as administrator for restore points.
echo Close Fortnite before applying its configuration tweaks.
echo Press Ctrl+C to stop PTweaks.
echo.
"%~dp0runtime\node.exe" "%~dp0server\desktop.mjs"
set "ptweaks_exit=%errorlevel%"
if not "%ptweaks_exit%"=="0" (
  echo.
  echo PTweaks stopped with an error. Read the message above.
  pause
)
exit /b %ptweaks_exit%
