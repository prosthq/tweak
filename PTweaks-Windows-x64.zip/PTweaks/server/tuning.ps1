# Fixed, reversible Windows tuning helpers. Dot-sourced by windows.ps1.
function Get-PowerSettingDefinitions {
  return @{
    'usb-selective-suspend-off' = @{ Subgroup = '2a737441-1930-4402-8d77-b2bebba308a3'; Setting = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'; Value = 0 }
    'pcie-link-state-off' = @{ Subgroup = '501a4d13-42af-4429-9fd1-a8218c268e20'; Setting = 'ee12f906-d277-404b-b6da-e5fa1a576df5'; Value = 0 }
  }
}

function Get-PowerSettingState($scheme, $definition) {
  if ($scheme -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$') { throw 'Invalid saved power plan ID.' }
  $output = (& powercfg.exe /query $scheme $definition.Subgroup $definition.Setting 2>&1) -join "`n"
  if ($LASTEXITCODE -ne 0) { throw 'This power setting is not available in the selected Windows power plan.' }
  # AC and DC indexes are the two 0x values in powercfg output; labels are localized.
  $indexes = @([regex]::Matches($output, '0x([0-9a-fA-F]{8})'))
  if ($indexes.Count -ne 2) { throw 'Windows power-setting indexes could not be read unambiguously.' }
  return @{ AC = [Convert]::ToUInt32($indexes[0].Groups[1].Value, 16); DC = [Convert]::ToUInt32($indexes[1].Groups[1].Value, 16) }
}

function Set-ACPowerSetting($scheme, $definition, $value) {
  $null = & powercfg.exe /setacvalueindex $scheme $definition.Subgroup $definition.Setting $value 2>&1
  if ($LASTEXITCODE -ne 0) { throw 'Windows refused the AC power-setting change. Check power-policy permissions.' }
  $state = Get-PowerSettingState $scheme $definition
  if ($state.AC -ne [uint32]$value) { throw 'The AC power-setting change could not be verified.' }
  if ((Get-ActivePowerGuid) -eq $scheme) { Set-PowerGuid $scheme }
}

function Apply-PowerSetting($id, $backupFile) {
  $definition = $powerSettings[$id]
  $scheme = Get-ActivePowerGuid
  $original = Get-PowerSettingState $scheme $definition
  $backup = @{ Id = $id; Kind = 'power-setting'; Applied = $false; SchemeGuid = $scheme; OriginalAC = $original.AC; OriginalDC = $original.DC; TargetAC = $definition.Value; CreatedAt = [DateTime]::UtcNow.ToString('o') }
  Save-Backup $backup $backupFile
  try {
    Set-ACPowerSetting $scheme $definition $definition.Value
    if ((Get-PowerSettingState $scheme $definition).DC -ne $original.DC) { throw 'The battery power index changed unexpectedly; original AC settings remain backed up.' }
    $backup.Applied = $true
    Save-Backup $backup $backupFile
  } catch {
    Set-ACPowerSetting $scheme $definition $original.AC
    Remove-Item -LiteralPath $backupFile -Force
    throw
  }
}

function Restore-PowerSetting($id, $backup) {
  $definition = $powerSettings[$id]
  if ($backup.Kind -ne 'power-setting' -or $backup.TargetAC -ne $definition.Value) { throw 'The saved power-setting backup is incompatible. No change was made.' }
  $state = Get-PowerSettingState $backup.SchemeGuid $definition
  if ($state.AC -ne $backup.TargetAC -and $state.AC -ne $backup.OriginalAC) { throw 'This AC power setting changed after PTweaks applied it. Undo was stopped to preserve your newer value.' }
  # Restore only AC on its original scheme; never replace a newer active scheme or battery setting.
  Set-ACPowerSetting $backup.SchemeGuid $definition $backup.OriginalAC
}

function Assert-LocalExecutable($path) {
  if ($path -notmatch '^[A-Za-z]:\\' -or [IO.Path]::GetExtension($path) -ne '.exe') { throw 'The Fortnite executable is not on a supported local drive.' }
  $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
  if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'The Fortnite executable is not a regular local file.' }
  $parent = $item.Directory
  while ($parent) {
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'The Fortnite installation is reached through a junction or symbolic link.' }
    $parent = $parent.Parent
  }
  return $item.FullName
}

function Get-FortniteExecutable {
  $candidates = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  if ($env:PROGRAMDATA) {
    $manifestRoot = Join-Path $env:PROGRAMDATA 'Epic\EpicGamesLauncher\Data\Manifests'
    if (Test-Path -LiteralPath $manifestRoot -PathType Container) {
      foreach ($file in @(Get-ChildItem -LiteralPath $manifestRoot -Filter '*.item' -File -ErrorAction SilentlyContinue)) {
        if ($file.Length -gt 1MB -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
        try {
          $manifest = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
          if ($manifest.AppName -ne 'Fortnite' -or !$manifest.InstallLocation) { continue }
          $path = Join-Path $manifest.InstallLocation 'FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe'
          if (Test-Path -LiteralPath $path -PathType Leaf) { $null = $candidates.Add((Assert-LocalExecutable $path)) }
        } catch { }
      }
    }
  }
  foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if (!$root) { continue }
    $path = Join-Path $root 'Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe'
    if (Test-Path -LiteralPath $path -PathType Leaf) { $null = $candidates.Add((Assert-LocalExecutable $path)) }
  }
  if ($candidates.Count -ne 1) { throw 'A single installed Fortnite executable could not be detected. Use Windows Settings > Display > Graphics to choose the game manually.' }
  return @($candidates)[0]
}

function Get-RegistryDefinitions($id) {
  if ($id -ne 'fortnite-gpu-preference') { return $actions[$id] }
  $path = Get-FortniteExecutable
  $item = Registry-Item 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' $path '' 'String'
  $original = Get-Original $item
  $value = ''
  if ($original.Exists) {
    if ($original.Kind -ne 'String' -or [string]$original.Value -match '[\r\n]') { throw 'The existing game graphics preference has an unsupported format.' }
    $value = [string]$original.Value
  }
  $pattern = '(?i)(^|;)GpuPreference=\d+(?=;|$)'
  if ([regex]::Matches($value, $pattern).Count -gt 1) { throw 'The existing GPU preference contains duplicate values. Use Windows Graphics settings instead.' }
  if ($value -match $pattern) { $value = [regex]::Replace($value, $pattern, '${1}GpuPreference=2') }
  else { if ($value -and !$value.EndsWith(';')) { $value += ';' }; $value += 'GpuPreference=2;' }
  $item.Value = $value
  return @($item)
}

function Get-ActionGroup($id) {
  if ($id -like 'fortnite-fps-cap-*') { return 'fortnite-fps-cap' }
  if ($id -in @('fortnite-view-distance', 'fortnite-view-distance-low')) { return 'fortnite-view-distance' }
  if ($id -like 'fortnite-resolution-*') { return 'fortnite-resolution' }
  if ($id -in @('balanced-power-plan', 'high-performance-power-plan')) { return 'power-plan' }
  return $null
}

function Assert-CompatibleBatch($ids) {
  $groups = @{}
  foreach ($id in @($ids)) {
    if (!(Test-KnownAction $id)) { throw 'Unknown tweak ID.' }
    $group = Get-ActionGroup $id
    if (!$group) { continue }
    if ($groups.ContainsKey($group) -and $groups[$group] -ne $id) { throw "Choose only one alternative in ${group}. No changes were made." }
    $groups[$group] = $id
  }
}

function Assert-CurrentGroupCompatible($id) {
  $group = Get-ActionGroup $id
  if (!$group) { return }
  foreach ($other in @(@(Get-Applied) + @(Get-Recovery))) {
    if ($other -ne $id -and (Get-ActionGroup $other) -eq $group) { throw "Undo $other in Restore center before applying $id. These alternatives share original settings." }
  }
}

function Get-WindowsBuild { return [Environment]::OSVersion.Version.Build }
