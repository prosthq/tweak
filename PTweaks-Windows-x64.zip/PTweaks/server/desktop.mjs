import http from 'node:http';
import net from 'node:net';
import { spawn, execFile } from 'node:child_process';
import { createReadStream } from 'node:fs';
import { realpath, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const contentTypes = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};

function isInside(root, target) {
  const relative = path.relative(root, target);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function validHost(host, port) {
  return new RegExp(`^(?:127\\.0\\.0\\.1|localhost|\\[::1\\]):${port}$`, 'i').test(host || '');
}

function validOrigin(origin, port) {
  if (!origin) return true;
  try {
    const value = new URL(origin);
    return value.protocol === 'http:' && !value.username && !value.password
      && ['127.0.0.1', 'localhost', '[::1]'].includes(value.hostname)
      && value.port === String(port);
  } catch { return false; }
}

function response(res, code, message) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify({ message }));
}

async function assertFreePort(port) {
  const probe = net.createServer();
  await new Promise((resolve, reject) => {
    probe.once('error', reject);
    probe.listen({ host: '127.0.0.1', port, exclusive: true }, resolve);
  });
  await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
}

async function requestBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16_384) throw Object.assign(new Error('Request body is too large.'), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function proxyApi(req, res, apiPort) {
  if (!['GET', 'HEAD', 'POST'].includes(req.method)) return response(res, 405, 'Method not allowed.');
  const body = req.method === 'POST' ? await requestBody(req) : null;
  const headers = { host: `127.0.0.1:${apiPort}` };
  if (req.headers.origin) headers.origin = req.headers.origin;
  if (req.headers['content-type']) headers['content-type'] = req.headers['content-type'];
  if (body) headers['content-length'] = String(body.length);
  await new Promise(resolve => {
    const upstream = http.request({ host: '127.0.0.1', port: apiPort, method: req.method, path: req.url, headers }, incoming => {
      res.writeHead(incoming.statusCode || 502, incoming.headers);
      incoming.pipe(res);
      incoming.on('end', resolve);
      incoming.on('error', error => { if (!res.writableEnded) res.destroy(error); resolve(); });
    });
    upstream.setTimeout(130_000, () => upstream.destroy(new Error('The Windows companion did not respond in time.')));
    upstream.on('error', () => {
      if (!res.headersSent) response(res, 502, 'The local Windows companion is unavailable. Restart PTweaks.');
      else if (!res.writableEnded) res.end();
      resolve();
    });
    res.on('close', () => { if (!res.writableEnded) upstream.destroy(); });
    upstream.end(body);
  });
}

async function serveAsset(req, res, root) {
  if (!['GET', 'HEAD'].includes(req.method)) return response(res, 405, 'Method not allowed.');
  let decoded;
  try { decoded = decodeURIComponent((req.url || '/').split(/[?#]/, 1)[0]); }
  catch { return response(res, 400, 'Invalid URL encoding.'); }
  if (!decoded.startsWith('/') || decoded.includes('\\') || decoded.includes('\0')
    || decoded.split('/').some(segment => segment === '..' || segment === '.')) {
    return response(res, 403, 'This path is not allowed.');
  }
  const candidate = path.resolve(root, decoded === '/' ? 'index.html' : decoded.slice(1));
  if (!isInside(root, candidate)) return response(res, 403, 'This path is not allowed.');
  let actual;
  let info;
  try {
    actual = await realpath(candidate);
    if (!isInside(root, actual)) return response(res, 403, 'This path is not allowed.');
    info = await stat(actual);
  } catch (error) {
    return response(res, error.code === 'ENOENT' || error.code === 'ENOTDIR' ? 404 : 403, 'File not found or unavailable.');
  }
  if (!info.isFile()) return response(res, 404, 'File not found.');
  const extension = path.extname(actual).toLowerCase();
  res.writeHead(200, {
    'Content-Type': contentTypes[extension] || 'application/octet-stream',
    'Content-Length': String(info.size),
    'Cache-Control': extension === '.html' ? 'no-store' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  });
  if (req.method === 'HEAD') return res.end();
  const stream = createReadStream(actual);
  stream.on('error', error => res.destroy(error));
  stream.pipe(res);
}

function waitForCompanion(child, port) {
  return new Promise((resolve, reject) => {
    let output = '';
    const timer = setTimeout(() => finish(new Error('The Windows companion did not start in time.')), 15_000);
    const onData = chunk => {
      output = (output + chunk.toString()).slice(-8000);
      if (output.includes(`PTweaks bridge listening on 127.0.0.1:${port}`)) finish();
    };
    const onExit = () => finish(new Error('The Windows companion exited before startup. Another PTweaks window may already be using its port.'));
    const onError = error => finish(error);
    function finish(error) {
      clearTimeout(timer);
      child.stdout.off('data', onData);
      child.off('exit', onExit);
      child.off('error', onError);
      error ? reject(error) : resolve();
    }
    child.stdout.on('data', onData);
    child.once('exit', onExit);
    child.once('error', onError);
  });
}

export async function startPortable() {
  const apiPort = Number(process.env.PTWEAKS_PORT || process.env.FRAMEFORGE_PORT || 4318);
  const uiPort = Number(process.env.PTWEAKS_UI_PORT || 5173);
  if (!Number.isInteger(apiPort) || apiPort < 1 || apiPort > 65535) throw new Error('Invalid PTWEAKS_PORT.');
  if (![5173, 4173].includes(uiPort)) throw new Error('PTWEAKS_UI_PORT must be 5173 or 4173.');
  if (apiPort === uiPort) throw new Error('The companion and interface need different ports.');
  const root = await realpath(path.resolve(directory, '..', 'dist'));
  if (!(await stat(path.join(root, 'index.html'))).isFile()) throw new Error('The packaged interface is missing. Extract the complete PTweaks ZIP and try again.');
  try { await assertFreePort(uiPort); await assertFreePort(apiPort); }
  catch (error) { throw new Error(`PTweaks cannot open its local ports. Close another PTweaks window or the application using port ${error.port || uiPort}, then try again.`); }

  const child = spawn(process.execPath, [path.join(directory, 'index.mjs')], {
    cwd: path.resolve(directory, '..'),
    env: { ...process.env, PTWEAKS_PORT: String(apiPort) },
    stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  child.stdout.on('data', chunk => process.stdout.write(chunk));
  child.stderr.on('data', chunk => process.stderr.write(chunk));
  let stopping = false;
  let ui;
  let closePromise;
  const onExit = () => {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGTERM');
  };
  const close = (code = 0) => {
    if (closePromise) return closePromise;
    stopping = true;
    process.exitCode = code;
    closePromise = (async () => {
      process.off('SIGINT', onSignal);
      process.off('SIGTERM', onSignal);
      if (ui?.listening) {
        const closed = new Promise(resolve => ui.close(resolve));
        ui.closeAllConnections();
        await closed;
      }
      if (child.exitCode === null && child.signalCode === null) {
        await new Promise(resolve => { child.once('exit', resolve); child.kill('SIGTERM'); });
      }
      process.off('exit', onExit);
    })();
    return closePromise;
  };
  const onSignal = () => { void close(); };
  process.once('SIGINT', onSignal);
  process.once('SIGTERM', onSignal);
  process.once('exit', onExit);
  child.on('exit', (code, signal) => {
    if (!stopping) { console.error(`PTweaks companion stopped (${signal || code}). Close this window and start PTweaks again.`); void close(code || 1); }
  });

  try {
    await waitForCompanion(child, apiPort);
    const health = await fetch(`http://127.0.0.1:${apiPort}/api/actions`, { signal: AbortSignal.timeout(5000) });
    const details = await health.json();
    if (!health.ok || !Array.isArray(details.actions) || !details.actions.some(action => action.id === 'game-mode')) throw new Error('The Windows companion did not report a valid startup response.');
    ui = http.createServer(async (req, res) => {
      try {
        if (!validHost(req.headers.host, uiPort) || !validOrigin(req.headers.origin, uiPort)) return response(res, 403, 'Only local PTweaks requests are allowed.');
        if (!req.url || req.url.length > 4096) return response(res, 400, 'Invalid request URL.');
        if (req.url === '/api' || req.url.startsWith('/api/') || req.url.startsWith('/api?')) return await proxyApi(req, res, apiPort);
        await serveAsset(req, res, root);
      } catch (error) {
        if (!res.headersSent) response(res, error.status || 500, error.status ? error.message : 'PTweaks could not process this request.');
        else if (!res.writableEnded) res.end();
      }
    });
    ui.headersTimeout = 10_000;
    ui.requestTimeout = 15_000;
    await new Promise((resolve, reject) => {
      ui.once('error', reject);
      ui.listen({ host: '127.0.0.1', port: uiPort, exclusive: true }, resolve);
    });
    const url = `http://127.0.0.1:${uiPort}`;
    console.log(`PTweaks portable ready at ${url}`);
    console.log('Keep this window open while using PTweaks. Press Ctrl+C to stop it.');
    if (process.platform === 'win32' && process.env.PTWEAKS_NO_OPEN !== '1') {
      execFile('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', `Start-Process -FilePath '${url}/'`], { windowsHide: true }, error => {
        if (error) console.error(`Your browser could not be opened automatically. Open ${url} in your browser.`);
      });
    }
    return { server: ui, child, url, close };
  } catch (error) {
    await close(1);
    throw error;
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  startPortable().catch(error => { console.error(`PTweaks startup failed: ${error.message}`); process.exitCode = 1; });
}
