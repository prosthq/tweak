param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('System', 'CleanupPreview', 'Cleanup', 'Restore', 'Tweaks', 'Preflight')]
  [string]$Operation,
  [string]$Payload = 'e30='
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$data = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
$stateRoot = Join-Path $env:LOCALAPPDATA 'PTweaks\backups'
$legacyStateRoot = Join-Path $env:LOCALAPPDATA 'FrameForge\backups'

function Test-Admin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Registry-Item($Path, $Name, $Value, $Kind = 'DWord', $ClearFlag = 0, $Default = $null) {
  return @{ Path = $Path; Name = $Name; Value = $Value; Kind = $Kind; ClearFlag = $ClearFlag; Default = $Default }
}

$dvr = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'
$content = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
$advanced = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
$actions = @{
  'game-mode' = @((Registry-Item 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1), (Registry-Item 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1))
  'game-capture-off' = @((Registry-Item 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0), (Registry-Item $dvr 'AppCaptureEnabled' 0))
  'background-recording-off' = @((Registry-Item $dvr 'HistoricalCaptureEnabled' 0))
  'mouse-acceleration-off' = @((Registry-Item 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '0' 'String'), (Registry-Item 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '0' 'String'), (Registry-Item 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '0' 'String'))
  'mouse-trails-off' = @((Registry-Item 'HKCU:\Control Panel\Mouse' 'MouseTrails' '0' 'String'))
  'transparency-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0))
  'animations-off' = @((Registry-Item 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String'))
  'menu-delay' = @((Registry-Item 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '100' 'String'))
  'taskbar-widgets-off' = @((Registry-Item $advanced 'TaskbarDa' 0))
  'taskbar-search-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0))
  'task-view-off' = @((Registry-Item $advanced 'ShowTaskViewButton' 0))
  'news-interests-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds' 'ShellFeedsTaskbarViewMode' 2))
  'web-search-off' = @((Registry-Item 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1))
  'suggestions-off' = @((Registry-Item $content 'SystemPaneSuggestionsEnabled' 0))
  'tips-off' = @((Registry-Item $content 'SubscribedContent-338389Enabled' 0))
  'tailored-experiences-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' 'TailoredExperiencesWithDiagnosticDataEnabled' 0))
  'content-suggestions-off' = @((Registry-Item $content 'SilentInstalledAppsEnabled' 0), (Registry-Item $content 'PreInstalledAppsEnabled' 0), (Registry-Item $content 'OemPreInstalledAppsEnabled' 0))
  'lockscreen-tips-off' = @((Registry-Item $content 'RotatingLockScreenOverlayEnabled' 0))
  'sticky-keys-off' = @((Registry-Item 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags' $null 'String' 4 510))
  'filter-keys-off' = @((Registry-Item 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags' $null 'String' 4 126))
  'toggle-keys-off' = @((Registry-Item 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags' $null 'String' 4 62))
  'notifications-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications' 'ToastEnabled' 0))
  'sync-provider-off' = @((Registry-Item $advanced 'ShowSyncProviderNotifications' 0))
  'welcome-experience-off' = @((Registry-Item $content 'SubscribedContent-310093Enabled' 0))
  'settings-suggestions-off' = @((Registry-Item $content 'SubscribedContent-338393Enabled' 0), (Registry-Item $content 'SubscribedContent-353694Enabled' 0), (Registry-Item $content 'SubscribedContent-353696Enabled' 0))
  'restart-apps-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' 'RestartApps' 0))
  'taskbar-animations-off' = @((Registry-Item $advanced 'TaskbarAnimations' 0))
  'peek-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\DWM' 'EnableAeroPeek' 0))
  'clipboard-history-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Clipboard' 'EnableClipboardHistory' 0))
  'clipboard-sync-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Clipboard' 'CloudClipboardAutomaticUpload' 0))
  'autoplay-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers' 'DisableAutoplay' 1))
  'advertising-id-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0))
  'audio-ducking-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Multimedia\Audio' 'UserDuckingPreference' 3))
  'search-history-off' = @((Registry-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings' 'IsDeviceSearchHistoryEnabled' 0))
  'gamebar-controller-off' = @((Registry-Item 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 0))
  'start-tracking-off' = @((Registry-Item $advanced 'Start_TrackProgs' 0))
}

function Get-Original($item) {
  $exists = $false
  $value = $null
  $kind = $null
  $key = Get-Item -LiteralPath $item.Path -ErrorAction SilentlyContinue
  if ($null -ne $key -and $key.GetValueNames() -contains $item.Name) {
    $exists = $true
    $kind = $key.GetValueKind($item.Name).ToString()
    if ($kind -notin @('String', 'ExpandString', 'Binary', 'DWord', 'MultiString', 'QWord', 'None')) { throw "Unsupported original registry type for $($item.Name); no change made." }
    $value = $key.GetValue($item.Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
  }
  return @{ Path = $item.Path; Name = $item.Name; Exists = $exists; Kind = $kind; Value = $value }
}

function Set-RegistryValue($path, $name, $value, $kind) {
  if (!(Test-Path -LiteralPath $path)) { $null = New-Item -Path $path -Force }
  $key = Get-Item -LiteralPath $path
  $typed = $value
  switch ($kind) {
    'DWord' { $typed = [int]$value }
    'QWord' { $typed = [long]$value }
    'Binary' { $typed = [byte[]]$value }
    'None' { $typed = [byte[]]$value }
    'MultiString' { $typed = [string[]]$value }
    default { $typed = [string]$value }
  }
  $registryKind = [Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind], $kind)
  $key.SetValue($name, $typed, $registryKind)
  if ($key.GetValueKind($name) -ne $registryKind -or [string]$key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) -cne [string]$typed) { throw "Registry verification failed for $name. Original settings remain backed up." }
}

function Save-Backup($backup, $path) {
  $temporary = $path + '.pending'
  $backup | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temporary -Encoding UTF8 -ErrorAction Stop
  Move-Item -LiteralPath $temporary -Destination $path -Force -ErrorAction Stop
}

function Restore-Values($values) {
  foreach ($value in $values) {
    if ($value.Exists) {
      Set-RegistryValue $value.Path $value.Name $value.Value $value.Kind
    } elseif (Test-Path -LiteralPath $value.Path) {
      Remove-ItemProperty -LiteralPath $value.Path -Name $value.Name -ErrorAction SilentlyContinue
      $key = Get-Item -LiteralPath $value.Path
      if ($key.GetValueNames() -contains $value.Name) { throw "Could not remove restored registry value $($value.Name)." }
    }
  }
}

# Only fixed code-owned action IDs can select a backup file.
$powerActions = @{ 'balanced-power-plan' = '381b4222-f694-41f0-9685-ff5bb260df2e'; 'high-performance-power-plan' = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
. (Join-Path $PSScriptRoot 'fortnite.ps1')
$fortniteActions = Get-FortniteDefinitions
. (Join-Path $PSScriptRoot 'tuning.ps1')
$powerSettings = Get-PowerSettingDefinitions

function Test-KnownAction($id) {
  return $actions.ContainsKey($id) -or $fortniteActions.ContainsKey($id) -or $powerActions.ContainsKey($id) -or $powerSettings.ContainsKey($id) -or $id -eq 'fortnite-gpu-preference'
}

function Get-BackupFile($id) {
  if (!(Test-KnownAction $id)) { throw 'Unknown tweak ID.' }
  $current = Join-Path $stateRoot ($id + '.json')
  $legacy = Join-Path $legacyStateRoot ($id + '.json')
  if ((Test-Path -LiteralPath $current) -and (Test-Path -LiteralPath $legacy)) {
    throw 'Both PTweaks and legacy backups exist for this tweak. Preserve both and resolve the duplicate originals before changing it.'
  }
  if (Test-Path -LiteralPath $legacy) { return $legacy }
  return $current
}

function Get-BackupIds($applied) {
  $result = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($root in @($stateRoot, $legacyStateRoot)) {
    if (!(Test-Path -LiteralPath $root)) { continue }
    foreach ($file in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)) {
      try {
        $backup = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
        if ((Test-KnownAction $backup.Id) -and [bool]$backup.Applied -eq $applied) { $null = $result.Add($backup.Id) }
      } catch { }
    }
  }
  return @($result)
}

function Get-Applied { return @(Get-BackupIds $true) }
function Get-Recovery { return @(Get-BackupIds $false) }

function Get-ActivePowerGuid {
  $output = (& powercfg.exe /getactivescheme 2>&1) -join ' '
  if ($LASTEXITCODE -ne 0 -or $output -notmatch '([a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12})') { throw 'Windows could not report the active power plan.' }
  return $Matches[1].ToLowerInvariant()
}

function Set-PowerGuid($guid) {
  if ($guid -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$') { throw 'Invalid saved power plan ID.' }
  $null = & powercfg.exe /setactive $guid 2>&1
  if ($LASTEXITCODE -ne 0 -or (Get-ActivePowerGuid) -ne $guid) { throw 'Windows could not activate the selected power plan.' }
}

function Test-ActionReady($id) {
  try {
    if (!(Test-KnownAction $id)) { throw 'Unknown tweak ID.' }
    Assert-CurrentGroupCompatible $id
    $build = Get-WindowsBuild
    if ($build -lt 10240) { throw 'This action requires Windows 10 or Windows 11.' }
    if ($id -eq 'taskbar-widgets-off' -and $build -lt 22000) { throw 'Taskbar Widgets are a Windows 11 feature.' }
    if ($id -eq 'news-interests-off' -and ($build -lt 19041 -or $build -ge 22000)) { throw 'News and interests is a supported Windows 10 taskbar feature; use Widgets on Windows 11.' }
    if ($id -eq 'game-mode' -and $build -lt 15063) { throw 'Game Mode requires a newer Windows build.' }
    $backupFile = Get-BackupFile $id
    if (Test-Path -LiteralPath $backupFile) {
      $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
      if ($backup.Id -ne $id) { throw 'Saved original settings do not match this action.' }
      if (!$backup.Applied) { throw 'Undo the incomplete operation in Restore center before applying again.' }
    }
    if ($fortniteActions.ContainsKey($id)) { return Test-FortniteAction $id }
    if ($powerActions.ContainsKey($id)) {
      $null = Get-ActivePowerGuid
      $null = & powercfg.exe /query $powerActions[$id] 2>&1
      if ($LASTEXITCODE -ne 0) { throw 'The requested Windows power plan is not available on this PC.' }
      return @{ ready = $true; reason = 'The requested power plan is available. Your active power plan will be saved for undo.' }
    }
    if ($powerSettings.ContainsKey($id)) {
      $null = Get-PowerSettingState (Get-ActivePowerGuid) $powerSettings[$id]
      return @{ ready = $true; reason = 'The AC power setting is exposed by the active plan. Only AC is changed; its original value is saved for undo.' }
    }
    foreach ($item in @(Get-RegistryDefinitions $id)) { $null = Get-Original $item }
    return @{ ready = $true; reason = 'Per-user Windows setting is supported. Sign out or restart may be needed; some Windows builds can ignore cosmetic policies.' }
  } catch { return @{ ready = $false; reason = $_.Exception.Message } }
}

function Get-Preflight {
  Assert-CompatibleBatch @($data.ids)
  $checks = @(foreach ($id in @($data.ids)) {
    $check = Test-ActionReady $id
    @{ id = $id; ready = [bool]$check.ready; reason = [string]$check.reason }
  })
  return @{ checks = $checks }
}

function Get-System {
  $cpu = @(Get-CimInstance Win32_Processor)
  $memory = @(Get-CimInstance Win32_PhysicalMemory)
  $os = Get-CimInstance Win32_OperatingSystem
  $gpu = @(Get-CimInstance Win32_VideoController)
  $board = Get-CimInstance Win32_BaseBoard | Select-Object -First 1
  $drives = @(Get-CimInstance Win32_DiskDrive)
  $totalMemory = ($memory | Measure-Object -Property Capacity -Sum).Sum
  $speeds = @($memory | ForEach-Object { if ($_.ConfiguredClockSpeed) { $_.ConfiguredClockSpeed } elseif ($_.Speed) { $_.Speed } } | Sort-Object -Unique)
  $memoryType = if (@($memory | Where-Object { $_.SMBIOSMemoryType -eq 26 }).Count -eq $memory.Count) { ' DDR4' } elseif (@($memory | Where-Object { $_.SMBIOSMemoryType -eq 34 }).Count -eq $memory.Count) { ' DDR5' } else { '' }
  $disk = New-Object IO.DriveInfo($env:SystemDrive)
  $admin = Test-Admin
  $restore = @{ available = $false; lastCreated = $null }
  if ($admin) {
    try {
      $points = @(Get-ComputerRestorePoint -ErrorAction Stop)
      $last = $points | Where-Object { ($_.Description -like 'PTweaks*' -or $_.Description -like 'FrameForge*') } | Sort-Object SequenceNumber -Descending | Select-Object -First 1
      $restore.available = $true
      if ($last) { $restore.lastCreated = ([Management.ManagementDateTimeConverter]::ToDateTime($last.CreationTime)).ToUniversalTime().ToString('o') }
    } catch { }
  }
  $memoryUsage = if ($os.TotalVisibleMemorySize -gt 0) { [Math]::Round((1 - $os.FreePhysicalMemory / $os.TotalVisibleMemorySize) * 100, 1) } else { $null }
  return @{
    mode = 'native'; platform = 'win32'; admin = $admin
    specs = @{
      cpu = ($cpu | ForEach-Object { $_.Name.Trim() }) -join ' / '
      gpu = ($gpu | ForEach-Object { $_.Name }) -join ' / '
      memory = ('{0:0.##} GB' -f ($totalMemory / 1GB))
      memoryType = $memoryType.Trim()
      memorySpeed = if ($speeds.Count) { ($speeds -join ' / ') + ' MT/s' } else { $null }
      os = "$($os.Caption) (build $($os.BuildNumber))"
      motherboard = "$($board.Manufacturer) $($board.Product)".Trim()
      storage = ($drives | ForEach-Object { '{0} ({1:0} GB)' -f $_.Model, ($_.Size / 1GB) }) -join ' / '
      cores = [int]($cpu | Measure-Object NumberOfCores -Sum).Sum
      threads = [int]($cpu | Measure-Object NumberOfLogicalProcessors -Sum).Sum
    }
    metrics = @{ cpu = ($cpu | Measure-Object LoadPercentage -Average).Average; memory = $memoryUsage; gpu = $null }
    disk = @{ total = $disk.TotalSize; free = $disk.AvailableFreeSpace }
    restore = $restore; applied = @(Get-Applied); recovery = @(Get-Recovery)
  }
}

function Get-CleanupDefinitions {
  return @(
    @{ id = 'temp-files'; name = 'Temporary files'; description = 'Unused user Temp files older than 24 hours. Locked files are skipped.'; path = (Join-Path $env:LOCALAPPDATA 'Temp'); admin = $false },
    @{ id = 'windows-temp'; name = 'Windows temporary files'; description = 'System temporary files older than 24 hours. Administrator access required.'; path = (Join-Path $env:SystemRoot 'Temp'); admin = $true },
    @{ id = 'shader-cache'; name = 'DirectX shader cache'; description = 'Optional reset. Games must rebuild shaders, which may temporarily increase stutter.'; path = (Join-Path $env:LOCALAPPDATA 'D3DSCache'); admin = $false }
  )
}

function Get-SafeFiles($root) {
  if (!(Test-Path -LiteralPath $root -PathType Container)) { return @() }
  $rootItem = Get-Item -LiteralPath $root -Force
  if ($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { return @() }
  # Reject reparse points in parent paths as well as the target tree.
  $ancestor = $rootItem.Parent
  while ($ancestor) {
    if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { return @() }
    $ancestor = $ancestor.Parent
  }
  $cutoff = (Get-Date).AddHours(-24)
  $queue = New-Object 'System.Collections.Generic.Queue[string]'
  $queue.Enqueue($rootItem.FullName)
  $files = New-Object 'System.Collections.Generic.List[object]'
  while ($queue.Count -gt 0) {
    $directory = $queue.Dequeue()
    foreach ($item in @(Get-ChildItem -LiteralPath $directory -Force -ErrorAction SilentlyContinue)) {
      if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
      if ($item.PSIsContainer) { $queue.Enqueue($item.FullName) }
      elseif ($item.LastWriteTime -lt $cutoff) { $files.Add($item) }
    }
  }
  return $files.ToArray()
}

function Get-CleanupPreview {
  $admin = Test-Admin
  $items = @(foreach ($definition in Get-CleanupDefinitions) {
    $files = @()
    if (!$definition.admin -or $admin) { $files = @(Get-SafeFiles $definition.path) }
    $size = ($files | Measure-Object Length -Sum).Sum
    @{ id = $definition.id; name = $definition.name; description = $definition.description; bytes = [long]$size; files = $files.Count; requiresAdmin = [bool]($definition.admin -and !$admin) }
  })
  return @{ available = $true; items = $items; totalBytes = [long]($items | Measure-Object bytes -Sum).Sum }
}

function Invoke-Cleanup {
  $definitions = @(Get-CleanupDefinitions)
  $freed = [long]0
  $count = 0
  $errors = New-Object 'System.Collections.Generic.List[string]'
  foreach ($id in @($data.ids)) {
    $definition = $definitions | Where-Object { $_.id -eq $id } | Select-Object -First 1
    if (!$definition) { throw 'Unknown cleanup item.' }
    if ($definition.admin -and !(Test-Admin)) { $errors.Add("$($definition.name): administrator access required."); continue }
    foreach ($file in @(Get-SafeFiles $definition.path)) {
      try {
        # Re-read metadata immediately before deletion and refuse changed/reparse files.
        $current = Get-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
        if ($current.PSIsContainer -or ($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $current.LastWriteTime -ge (Get-Date).AddHours(-24)) { continue }
        $length = $current.Length
        Remove-Item -LiteralPath $current.FullName -Force -ErrorAction Stop
        $freed += $length
        $count++
      } catch { $errors.Add("Skipped a locked or inaccessible file in $($definition.name).") }
    }
  }
  return @{ freedBytes = $freed; files = $count; errors = @($errors | Select-Object -Unique) }
}

function New-RestorePoint {
  if (!(Test-Admin)) { throw 'Run PTweaks as administrator to create a Windows restore point.' }
  $before = @(Get-ComputerRestorePoint -ErrorAction Stop)
  $beforeSequence = ($before | Measure-Object SequenceNumber -Maximum).Maximum
  $name = if ($data.name) { [string]$data.name } else { 'PTweaks - before optimization' }
  Checkpoint-Computer -Description $name -RestorePointType MODIFY_SETTINGS -ErrorAction Stop -WarningAction SilentlyContinue
  $created = Get-ComputerRestorePoint -ErrorAction Stop | Where-Object { $_.SequenceNumber -gt $beforeSequence -and $_.Description -eq $name } | Sort-Object SequenceNumber -Descending | Select-Object -First 1
  if (!$created) { throw 'Windows did not create a new restore point. Check that System Protection is enabled. Windows may also enforce a restore-point frequency limit; existing protection was left unchanged.' }
  return @{ success = $true; createdAt = ([Management.ManagementDateTimeConverter]::ToDateTime($created.CreationTime)).ToUniversalTime().ToString('o'); message = 'Windows restore point created and verified.' }
}

function Invoke-Tweaks {
  if ($data.enabled -isnot [bool]) { throw 'enabled must be true or false.' }
  if ($data.ids -isnot [Array] -or $data.ids.Count -lt 1 -or $data.ids.Count -gt 100) { throw 'Choose one or more supported item IDs.' }
  foreach ($id in @($data.ids)) { if (!(Test-KnownAction $id)) { throw 'Unknown tweak ID.' } }
  if ($data.enabled) {
    Assert-CompatibleBatch @($data.ids)
    foreach ($id in @($data.ids)) { Assert-CurrentGroupCompatible $id }
  }
  $null = New-Item -ItemType Directory -Path $stateRoot -Force
  $errors = New-Object 'System.Collections.Generic.List[string]'
  foreach ($id in @($data.ids)) {
    if (!(Test-KnownAction $id)) { throw 'Unknown tweak ID.' }
    try {
      $backupFile = Get-BackupFile $id
      if (!$data.enabled) {
        if (!(Test-Path -LiteralPath $backupFile)) { continue }
        $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
        if ($backup.Id -ne $id) { throw 'Saved original settings do not match this action.' }
        if ($fortniteActions.ContainsKey($id)) { Restore-FortniteAction $backup }
        elseif ($powerSettings.ContainsKey($id)) { Restore-PowerSetting $id $backup }
        elseif ($powerActions.ContainsKey($id)) {
          $current = Get-ActivePowerGuid
          if ($current -ne $backup.TargetGuid -and $current -ne $backup.OriginalGuid) { throw 'Your power plan was changed after this tweak. Choose the saved plan manually or restore the expected plan before undoing.' }
          Set-PowerGuid $backup.OriginalGuid
        } else { Restore-Values $backup.Values }
        Remove-Item -LiteralPath $backupFile -Force
        continue
      }
      $check = Test-ActionReady $id
      if (!$check.ready) { throw $check.reason }
      if (Test-Path -LiteralPath $backupFile) { continue }
      if ($fortniteActions.ContainsKey($id)) { Apply-FortniteAction $id $backupFile; continue }
      if ($powerSettings.ContainsKey($id)) { Apply-PowerSetting $id $backupFile; continue }
      if ($powerActions.ContainsKey($id)) {
        $backup = @{ Id = $id; Kind = 'power'; Applied = $false; OriginalGuid = (Get-ActivePowerGuid); TargetGuid = $powerActions[$id]; CreatedAt = [DateTime]::UtcNow.ToString('o') }
        Save-Backup $backup $backupFile
        try {
          Set-PowerGuid $powerActions[$id]
          $backup.Applied = $true
          Save-Backup $backup $backupFile
        } catch {
          Set-PowerGuid $backup.OriginalGuid
          Remove-Item -LiteralPath $backupFile -Force
          throw
        }
        continue
      }
      $definitions = @(Get-RegistryDefinitions $id)
      $originals = @($definitions | ForEach-Object { Get-Original $_ })
      $backup = @{ Id = $id; Kind = 'registry'; Applied = $false; CreatedAt = [DateTime]::UtcNow.ToString('o'); Values = $originals }
      Save-Backup $backup $backupFile
      try {
        foreach ($item in $definitions) {
          $value = $item.Value
          if ($item.ClearFlag) {
            $original = $originals | Where-Object { $_.Path -eq $item.Path -and $_.Name -eq $item.Name } | Select-Object -First 1
            $current = if ($original.Exists) { [int]$original.Value } else { [int]$item.Default }
            $value = [string]($current -band (-bnot [int]$item.ClearFlag))
          }
          Set-RegistryValue $item.Path $item.Name $value $item.Kind
        }
        $backup.Applied = $true
        Save-Backup $backup $backupFile
      } catch {
        Restore-Values $originals
        Remove-Item -LiteralPath $backupFile -Force
        throw
      }
    } catch { $errors.Add("${id}: $($_.Exception.Message)") }
  }
  return @{ applied = @(Get-Applied); recovery = @(Get-Recovery); errors = $errors.ToArray(); message = 'Supported settings processed and verified. Restart the game, or sign out/restart Windows, for changes to take effect. Original settings are retained for undo.' }
}

try {
  $result = switch ($Operation) {
    'System' { Get-System }
    'CleanupPreview' { Get-CleanupPreview }
    'Cleanup' { Invoke-Cleanup }
    'Restore' { New-RestorePoint }
    'Tweaks' { Invoke-Tweaks }
    'Preflight' { Get-Preflight }
  }
  $result | ConvertTo-Json -Depth 14 -Compress
} catch {
  @{ error = $_.Exception.Message } | ConvertTo-Json -Compress
}
