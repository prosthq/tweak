import http from 'node:http';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const exec = promisify(execFile);
const port = Number(process.env.PTWEAKS_PORT || process.env.FRAMEFORGE_PORT || 4318);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid PTWEAKS_PORT');
const native = process.platform === 'win32' && process.env.PTWEAKS_TEST_PREVIEW !== '1' && process.env.FRAMEFORGE_TEST_PREVIEW !== '1';
const script = fileURLToPath(new URL('./windows.ps1', import.meta.url));

const actions = [
  ['game-mode', 'Enable Windows Game Mode'],
  ['game-capture-off', 'Disable Xbox game capture'],
  ['background-recording-off', 'Disable background game recording'],
  ['mouse-acceleration-off', 'Disable mouse acceleration'],
  ['mouse-trails-off', 'Disable pointer trails'],
  ['transparency-off', 'Disable Windows transparency'],
  ['animations-off', 'Reduce window animations'],
  ['menu-delay', 'Reduce menu display delay'],
  ['taskbar-widgets-off', 'Hide taskbar widgets'],
  ['taskbar-search-off', 'Hide taskbar search'],
  ['task-view-off', 'Hide Task View button'],
  ['news-interests-off', 'Hide News and interests'],
  ['web-search-off', 'Disable search box suggestions'],
  ['suggestions-off', 'Disable Start menu suggestions'],
  ['tips-off', 'Disable Windows tips'],
  ['tailored-experiences-off', 'Disable tailored diagnostic experiences'],
  ['content-suggestions-off', 'Disable suggested app installations'],
  ['lockscreen-tips-off', 'Disable lock screen tips'],
  ['sticky-keys-off', 'Disable Sticky Keys shortcut'],
  ['filter-keys-off', 'Disable Filter Keys shortcut'],
  ['toggle-keys-off', 'Disable Toggle Keys shortcut'],
  ['notifications-off', 'Disable Windows toast notifications'],
  ['sync-provider-off', 'Hide File Explorer sync-provider notifications'],
  ['welcome-experience-off', 'Disable Windows welcome suggestions'],
  ['settings-suggestions-off', 'Disable suggested content in Settings'],
  ['restart-apps-off', 'Disable automatic app restart at sign-in'],
  ['taskbar-animations-off', 'Disable taskbar animations'],
  ['peek-off', 'Disable desktop Peek'],
  ['clipboard-history-off', 'Disable clipboard history'],
  ['clipboard-sync-off', 'Disable automatic clipboard upload'],
  ['autoplay-off', 'Disable AutoPlay prompts'],
  ['advertising-id-off', 'Disable personalized advertising ID'],
  ['audio-ducking-off', 'Keep game volume during voice calls'],
  ['search-history-off', 'Disable device search history'],
  ['start-tracking-off', 'Disable Start app-launch tracking'],
].map(([id, title]) => ({ id, title, kind: 'registry' }));
actions.push(...[
  ['fortnite-shadows', 'Disable Fortnite shadows'],
  ['fortnite-textures', 'Lower Fortnite textures'],
  ['fortnite-effects', 'Lower Fortnite effects'],
  ['fortnite-post', 'Lower Fortnite post-processing'],
  ['fortnite-view-distance', 'Set Fortnite view distance to Medium'],
  ['fortnite-anti-aliasing', 'Lower Fortnite anti-aliasing quality'],
  ['fortnite-global-illumination', 'Lower Fortnite global illumination'],
  ['fortnite-reflections', 'Lower Fortnite reflections'],
  ['fortnite-foliage', 'Lower Fortnite foliage quality'],
  ['fortnite-shading', 'Lower Fortnite shading quality'],
  ['fortnite-vsync', 'Disable Fortnite V-Sync'],
  ['fortnite-motion-blur', 'Disable Fortnite motion blur'],
  ['fortnite-fullscreen', 'Set Fortnite fullscreen mode'],
  ['fortnite-fps-cap-144', 'Set Fortnite frame cap to 144 FPS'],
  ['fortnite-dynamic-resolution', 'Disable Fortnite dynamic resolution'],
].map(([id, title]) => ({ id, title, kind: 'fortnite' })));
actions.push({ id: 'balanced-power-plan', title: 'Use Windows Balanced power plan', kind: 'power' });
actions.push(...[
  ['fortnite-fps-cap-120', 'Set Fortnite frame cap to 120 FPS'],
  ['fortnite-fps-cap-141', 'Set Fortnite frame cap to 141 FPS'],
  ['fortnite-fps-cap-165', 'Set Fortnite frame cap to 165 FPS'],
  ['fortnite-fps-cap-240', 'Set Fortnite frame cap to 240 FPS'],
  ['fortnite-fps-cap-unlimited', 'Use an uncapped Fortnite frame rate'],
  ['fortnite-view-distance-low', 'Set Fortnite view distance to Low'],
  ['fortnite-resolution-native', 'Use native Fortnite 3D resolution'],
  ['fortnite-resolution-85', 'Use 85 percent Fortnite 3D resolution'],
  ['fortnite-nanite-off', 'Disable Fortnite Nanite'],
  ['fortnite-raytracing-off', 'Disable Fortnite hardware ray tracing'],
  ['fortnite-show-fps', 'Show Fortnite FPS counter'],
].map(([id, title]) => ({ id, title, kind: 'fortnite' })));
actions.push(
  { id: 'high-performance-power-plan', title: 'Compare Windows High performance plan', kind: 'power', experimental: true },
  { id: 'usb-selective-suspend-off', title: 'Disable AC USB selective suspend', kind: 'power', experimental: true },
  { id: 'pcie-link-state-off', title: 'Disable AC PCIe link-state power saving', kind: 'power', experimental: true },
  { id: 'fortnite-gpu-preference', title: 'Prefer the high-performance GPU for Fortnite', kind: 'registry' },
  { id: 'gamebar-controller-off', title: 'Disable controller Game Bar shortcut', kind: 'registry' },
);
for (const action of actions) {
  if (action.id.startsWith('fortnite-fps-cap-')) action.exclusiveGroup = 'fortnite-fps-cap';
  if (['fortnite-view-distance', 'fortnite-view-distance-low'].includes(action.id)) action.exclusiveGroup = 'fortnite-view-distance';
  if (action.id.startsWith('fortnite-resolution-')) action.exclusiveGroup = 'fortnite-resolution';
  if (['balanced-power-plan', 'high-performance-power-plan'].includes(action.id)) action.exclusiveGroup = 'power-plan';
}
const actionMetadata = new Map(actions.map(action => [action.id, action]));
function assertCompatible(ids) {
  const chosen = new Map();
  for (const id of ids) {
    const group = actionMetadata.get(id)?.exclusiveGroup;
    if (!group) continue;
    if (chosen.has(group) && chosen.get(group) !== id) {
      throw Object.assign(new Error(`Choose only one alternative in ${group}: ${chosen.get(group)} conflicts with ${id}. No changes were made.`), { status: 400 });
    }
    chosen.set(group, id);
  }
}

const actionIds = new Set(actions.map(({ id }) => id));
const cleanupIds = new Set(['temp-files', 'windows-temp', 'shader-cache']);
const previewMessage = 'Live Windows access is unavailable here. Run PTweaks locally on your Windows PC to scan or make changes. No system changes were made.';

function previewSystem() {
  return {
    mode: 'preview', platform: process.platform, admin: false,
    specs: {
      cpu: 'AMD Ryzen 5 5500', gpu: 'AMD Radeon RX 6600', memory: '32 GB', memoryType: 'DDR4',
      memorySpeed: '3200 MT/s', os: 'Windows required for live scan',
      motherboard: null, storage: null, cores: 6, threads: 12,
    },
    metrics: { cpu: null, memory: null, gpu: null }, disk: { total: null, free: null },
    restore: { available: false, lastCreated: null }, applied: [], recovery: [],
  };
}

function previewCleanup() {
  return {
    available: false, totalBytes: 0, message: previewMessage,
    items: [
      { id: 'temp-files', name: 'Temporary files', description: 'Unused files in your user Temp folder, older than 24 hours.', bytes: 0, files: 0 },
      { id: 'windows-temp', name: 'Windows temporary files', description: 'Old system temporary files. Administrator access required.', bytes: 0, files: 0 },
      { id: 'shader-cache', name: 'DirectX shader cache', description: 'Optional cache reset. Games must rebuild shaders, which may temporarily increase stutter.', bytes: 0, files: 0 },
    ],
  };
}

async function windows(operation, payload = {}) {
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64');
  const { stdout } = await exec('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'RemoteSigned',
    '-File', script, '-Operation', operation, '-Payload', encoded,
  ], { timeout: 120_000, maxBuffer: 4 * 1024 * 1024, windowsHide: true, encoding: 'utf8' });
  const parsed = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
  if (parsed.error) throw new Error(parsed.error);
  return parsed;
}

function respond(res, status, value) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(JSON.stringify(value));
}

function allowedHost(host) {
  try {
    const parsed = new URL(`http://${host}`);
    return ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
  } catch { return false; }
}

function allowedOrigin(origin) {
  try {
    const parsed = new URL(origin);
    return parsed.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname)
      && [String(port), '5173', '4173'].includes(parsed.port);
  } catch { return false; }
}

async function body(req) {
  if (!(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) {
    throw Object.assign(new Error('Use Content-Type: application/json.'), { status: 415 });
  }
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16_384) throw Object.assign(new Error('Request body is too large.'), { status: 413 });
    chunks.push(chunk);
  }
  let result;
  try { result = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Invalid JSON body.'), { status: 400 }); }
  if (!result || typeof result !== 'object' || Array.isArray(result)) {
    throw Object.assign(new Error('JSON body must be an object.'), { status: 400 });
  }
  return result;
}

function validateIds(ids, valid) {
  if (!Array.isArray(ids) || !ids.length || ids.length > 100 || ids.some(id => typeof id !== 'string' || !valid.has(id))) {
    throw Object.assign(new Error('Choose one or more supported item IDs.'), { status: 400 });
  }
  return [...new Set(ids)];
}

// Serialize state-changing operations to preserve original-value backups.
let mutation = Promise.resolve();
function mutate(operation, payload) {
  const result = mutation.then(() => windows(operation, payload));
  mutation = result.catch(() => {});
  return result;
}

const server = http.createServer(async (req, res) => {
  try {
    if (!allowedHost(req.headers.host || '') || (req.headers.origin && !allowedOrigin(req.headers.origin))) {
      return respond(res, 403, { message: 'Only local PTweaks requests are allowed.' });
    }
    const route = new URL(req.url || '/', 'http://127.0.0.1').pathname;
    if (req.method === 'GET' && route === '/api/system') {
      return respond(res, 200, native ? await windows('System') : previewSystem());
    }
    if (req.method === 'GET' && route === '/api/actions') {
      return respond(res, 200, { actions, supported: native });
    }
    if (req.method === 'GET' && route === '/api/cleanup') {
      return respond(res, 200, native ? await windows('CleanupPreview') : previewCleanup());
    }
    if (req.method !== 'POST' || !['/api/scan', '/api/tweaks', '/api/cleanup', '/api/restore', '/api/preflight'].includes(route)) {
      return respond(res, 404, { message: 'Endpoint not found.' });
    }
    const payload = await body(req);
    if (route === '/api/scan') return respond(res, 200, native ? await windows('System') : previewSystem());
    if (route === '/api/tweaks' || route === '/api/preflight') payload.ids = validateIds(payload.ids, actionIds);
    if (route === '/api/preflight') {
      assertCompatible(payload.ids);
      return respond(res, 200, native ? { mode: 'native', ...await windows('Preflight', payload) } : {
        mode: 'preview', checks: payload.ids.map(id => ({ id, ready: false, reason: previewMessage })),
      });
    }
    if (route === '/api/tweaks') {
      if (typeof payload.enabled !== 'boolean') throw Object.assign(new Error('enabled must be true or false.'), { status: 400 });
      if (payload.enabled) assertCompatible(payload.ids);
    }
    if (route === '/api/cleanup') payload.ids = validateIds(payload.ids, cleanupIds);
    if (route === '/api/restore' && payload.name !== undefined && (typeof payload.name !== 'string' || payload.name.length > 80)) {
      throw Object.assign(new Error('Restore point name must be at most 80 characters.'), { status: 400 });
    }
    if (!native) return respond(res, 409, { message: previewMessage });
    const operation = { '/api/tweaks': 'Tweaks', '/api/cleanup': 'Cleanup', '/api/restore': 'Restore' }[route];
    return respond(res, 200, await mutate(operation, payload));
  } catch (error) {
    const message = error.killed ? 'The Windows operation timed out. Check its status before retrying.' : error.message;
    respond(res, error.status || 500, { message: message || 'The Windows operation failed.' });
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`PTweaks bridge listening on 127.0.0.1:${port} (${native ? 'Windows native' : 'preview; no system changes'})`);
});

for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
