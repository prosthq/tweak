# Fixed, existing-key edits only. This file is dot-sourced by windows.ps1.
# No client-supplied file path, section, key, or value is accepted.

function Get-FortniteDefinitions {
  $quality = 'ScalabilityGroups'
  $game = '/Script/FortniteGame.FortGameUserSettings'
  return @{
    'fortnite-shadows' = @(@{ Section = $quality; Key = 'sg.ShadowQuality'; Value = '0' })
    'fortnite-textures' = @(@{ Section = $quality; Key = 'sg.TextureQuality'; Value = '0' })
    'fortnite-effects' = @(@{ Section = $quality; Key = 'sg.EffectsQuality'; Value = '0' })
    'fortnite-post' = @(@{ Section = $quality; Key = 'sg.PostProcessQuality'; Value = '0' })
    'fortnite-view-distance' = @(@{ Section = $quality; Key = 'sg.ViewDistanceQuality'; Value = '1' })
    'fortnite-anti-aliasing' = @(@{ Section = $quality; Key = 'sg.AntiAliasingQuality'; Value = '0' })
    'fortnite-global-illumination' = @(@{ Section = $quality; Key = 'sg.GlobalIlluminationQuality'; Value = '0' })
    'fortnite-reflections' = @(@{ Section = $quality; Key = 'sg.ReflectionQuality'; Value = '0' })
    'fortnite-foliage' = @(@{ Section = $quality; Key = 'sg.FoliageQuality'; Value = '0' })
    'fortnite-shading' = @(@{ Section = $quality; Key = 'sg.ShadingQuality'; Value = '0' })
    'fortnite-vsync' = @(@{ Section = $game; Key = 'bUseVSync'; Value = 'False' })
    'fortnite-motion-blur' = @(@{ Section = $game; Key = 'bMotionBlur'; Value = 'False' })
    'fortnite-fullscreen' = @(@{ Section = $game; Key = 'FullscreenMode'; Value = '0' })
    'fortnite-fps-cap-144' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '144.000000' })
    'fortnite-dynamic-resolution' = @(@{ Section = $game; Key = 'bUseDynamicResolution'; Value = 'False' })
    # Alternatives share keys. Their exclusive groups are enforced by the API
    # and Windows dispatcher before any backups or mutations are started.
    'fortnite-fps-cap-120' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '120.000000' })
    'fortnite-fps-cap-141' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '141.000000' })
    'fortnite-fps-cap-165' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '165.000000' })
    'fortnite-fps-cap-240' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '240.000000' })
    'fortnite-fps-cap-unlimited' = @(@{ Section = $game; Key = 'FrameRateLimit'; Value = '0.000000' })
    'fortnite-view-distance-low' = @(@{ Section = $quality; Key = 'sg.ViewDistanceQuality'; Value = '0' })
    'fortnite-resolution-native' = @(@{ Section = $quality; Key = 'sg.ResolutionQuality'; Value = '100.000000' })
    'fortnite-resolution-85' = @(@{ Section = $quality; Key = 'sg.ResolutionQuality'; Value = '85.000000' })
    'fortnite-nanite-off' = @(@{ Section = $game; Key = 'bUseNanite'; Value = 'False' })
    'fortnite-raytracing-off' = @(@{ Section = $game; Key = 'bRayTracing'; Value = 'False' })
    'fortnite-show-fps' = @(@{ Section = $game; Key = 'bShowFPS'; Value = 'True' })
  }
}

function Assert-FortniteClosed {
  if (@(Get-Process -Name 'Fortnite*' -ErrorAction SilentlyContinue).Count -gt 0) {
    throw 'Close Fortnite completely before changing or restoring its configuration.'
  }
}

function Get-FortniteConfigPaths {
  if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'The Windows local application-data folder is unavailable.' }
  return @(
    (Join-Path $env:LOCALAPPDATA 'FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini'),
    (Join-Path $env:LOCALAPPDATA 'FortniteGame\Saved\Config\Windows\GameUserSettings.ini')
  )
}

function Get-FortniteConfigPath {
  $found = @(Get-FortniteConfigPaths | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
  if ($found.Count -eq 0) { throw 'Fortnite configuration was not found. Launch Fortnite once, save its settings, then close it before applying this tweak.' }
  if ($found.Count -gt 1) { throw 'Multiple Fortnite configuration folders were found. Use the in-game setting until the active configuration is unambiguous.' }
  return $found[0]
}

function Assert-FortniteFile($path) {
  $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
  if ($item.PSIsContainer) { throw 'The Fortnite configuration is not a file.' }
  if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or ($item.Attributes -band [IO.FileAttributes]::ReadOnly)) {
    throw 'The Fortnite configuration is read-only or a symbolic link. Its protection was left unchanged.'
  }
  $parent = $item.Directory
  while ($parent) {
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'A Fortnite configuration parent is a symbolic link or junction. No file was changed.' }
    $parent = $parent.Parent
  }
  if ($item.Length -gt 2MB) { throw 'The Fortnite configuration is unexpectedly large. No file was changed.' }
}

function Get-FortniteHash([byte[]]$bytes) {
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return [Convert]::ToBase64String($sha.ComputeHash($bytes)) } finally { $sha.Dispose() }
}

function Read-FortniteIni($path) {
  Assert-FortniteFile $path
  $raw = [IO.File]::ReadAllBytes($path)
  $offset = 0
  $encoding = New-Object Text.UTF8Encoding($false, $true)
  if ($raw.Length -ge 4 -and $raw[0] -eq 255 -and $raw[1] -eq 254 -and $raw[2] -eq 0 -and $raw[3] -eq 0) {
    $offset = 4; $encoding = New-Object Text.UTF32Encoding($false, $true, $true)
  } elseif ($raw.Length -ge 4 -and $raw[0] -eq 0 -and $raw[1] -eq 0 -and $raw[2] -eq 254 -and $raw[3] -eq 255) {
    $offset = 4; $encoding = New-Object Text.UTF32Encoding($true, $true, $true)
  } elseif ($raw.Length -ge 3 -and $raw[0] -eq 239 -and $raw[1] -eq 187 -and $raw[2] -eq 191) {
    $offset = 3; $encoding = New-Object Text.UTF8Encoding($true, $true)
  } elseif ($raw.Length -ge 2 -and $raw[0] -eq 255 -and $raw[1] -eq 254) {
    $offset = 2; $encoding = New-Object Text.UnicodeEncoding($false, $true, $true)
  } elseif ($raw.Length -ge 2 -and $raw[0] -eq 254 -and $raw[1] -eq 255) {
    $offset = 2; $encoding = New-Object Text.UnicodeEncoding($true, $true, $true)
  }
  return @{ Path = $path; Bytes = $raw; Hash = (Get-FortniteHash $raw); Encoding = $encoding; Text = $encoding.GetString($raw, $offset, $raw.Length - $offset) }
}

function Get-FortniteIniValue([string]$text, [string]$section, [string]$key) {
  $currentSection = ''
  $found = New-Object 'System.Collections.Generic.List[object]'
  $keyPattern = '^(?<prefix>\s*' + [regex]::Escape($key) + '\s*=\s*)(?<value>.*?)(?<suffix>\s*)$'
  foreach ($line in [regex]::Matches($text, '[^\r\n]*(?:\r\n|\n|\r|$)')) {
    if (!$line.Length) { continue }
    $content = $line.Value.TrimEnd([char[]]"`r`n")
    if ($content -match '^\s*\[([^\]]+)\]\s*(?:[;#].*)?$') { $currentSection = $Matches[1]; continue }
    if ($currentSection -ne $section) { continue }
    $match = [regex]::Match($content, $keyPattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($match.Success) {
      $found.Add(@{ Start = $line.Index + $match.Groups['value'].Index; Length = $match.Groups['value'].Length; Value = $match.Groups['value'].Value })
    }
  }
  if ($found.Count -ne 1) { throw "Fortnite setting [$section] $key is missing or duplicated in this game version. Use its in-game setting instead." }
  return $found[0]
}

function Set-FortniteIniValues([string]$text, $values, [bool]$original = $false) {
  $updated = $text
  foreach ($value in $values) {
    $found = Get-FortniteIniValue $updated $value.Section $value.Key
    $replacement = if ($original) { [string]$value.Original } else { [string]$value.Applied }
    if ($replacement -match '[\r\n]') { throw 'A Fortnite configuration value is invalid.' }
    $updated = $updated.Remove($found.Start, $found.Length).Insert($found.Start, $replacement)
  }
  return $updated
}

function Write-FortniteIni($state, [string]$text) {
  Assert-FortniteClosed
  Assert-FortniteFile $state.Path
  $actual = [IO.File]::ReadAllBytes($state.Path)
  if ((Get-FortniteHash $actual) -ne $state.Hash) { throw 'Fortnite configuration changed during the operation. No overwrite was attempted.' }
  [byte[]]$encoded = @($state.Encoding.GetPreamble()) + @($state.Encoding.GetBytes($text))
  $temporary = $state.Path + '.ptweaks.' + [Guid]::NewGuid().ToString('N') + '.pending'
  $replacementBackup = $temporary + '.original'
  try {
    $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($encoded, 0, $encoded.Length); $stream.Flush($true) } finally { $stream.Dispose() }
    Assert-FortniteClosed
    Assert-FortniteFile $state.Path
    if ((Get-FortniteHash ([IO.File]::ReadAllBytes($state.Path))) -ne $state.Hash) { throw 'Fortnite configuration changed during the operation. No overwrite was attempted.' }
    # Atomic replacement on the same volume; never delete the destination first.
    [IO.File]::Replace($temporary, $state.Path, $replacementBackup)
    if ((Get-FortniteHash ([IO.File]::ReadAllBytes($state.Path))) -ne (Get-FortniteHash $encoded)) { throw 'The Fortnite configuration write could not be verified. Its original settings remain backed up.' }
  } finally {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $replacementBackup) { Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue }
  }
}

function Test-FortniteAction($id) {
  try {
    $definitions = Get-FortniteDefinitions
    if (!$definitions.ContainsKey($id)) { throw 'Unknown Fortnite action.' }
    Assert-FortniteClosed
    $state = Read-FortniteIni (Get-FortniteConfigPath)
    foreach ($definition in $definitions[$id]) { $null = Get-FortniteIniValue $state.Text $definition.Section $definition.Key }
    return @{ ready = $true; reason = 'Fortnite is closed and the supported setting exists. Original values will be backed up.' }
  } catch { return @{ ready = $false; reason = $_.Exception.Message } }
}

function Restore-FortniteAction($backup) {
  $definitions = Get-FortniteDefinitions
  if (!$definitions.ContainsKey([string]$backup.Id)) { throw 'Unknown Fortnite backup action.' }
  $allowedPaths = @(Get-FortniteConfigPaths)
  if ($allowedPaths -notcontains [string]$backup.Path) { throw 'The Fortnite backup path does not match a supported configuration location.' }
  Assert-FortniteClosed
  $state = Read-FortniteIni ([string]$backup.Path)
  $values = @($backup.Values)
  if ($values.Count -ne @($definitions[$backup.Id]).Count) { throw 'The Fortnite backup is incomplete. No setting was restored.' }
  foreach ($value in $values) {
    $definition = @($definitions[$backup.Id] | Where-Object { $_.Section -eq $value.Section -and $_.Key -eq $value.Key })
    if ($definition.Count -ne 1 -or $value.Applied -ne $definition[0].Value -or [string]$value.Original -match '[\r\n]') { throw 'The Fortnite backup contains an unsupported setting. No setting was restored.' }
    $current = Get-FortniteIniValue $state.Text $value.Section $value.Key
    if ($current.Value -ne [string]$value.Applied -and $current.Value -ne [string]$value.Original) {
      throw "Fortnite setting $($value.Key) changed after PTweaks applied it. Undo was stopped to preserve your newer value. Its original backup is retained."
    }
  }
  $restored = Set-FortniteIniValues $state.Text $values $true
  Write-FortniteIni $state $restored
}

function Apply-FortniteAction($id, $backupFile) {
  $definitions = Get-FortniteDefinitions
  if (!$definitions.ContainsKey($id)) { throw 'Unknown Fortnite action.' }
  Assert-FortniteClosed
  $state = Read-FortniteIni (Get-FortniteConfigPath)
  if (Test-Path -LiteralPath $backupFile) { throw 'An existing Fortnite backup must be undone before applying this tweak again.' }
  $values = @(foreach ($definition in $definitions[$id]) {
    $original = Get-FortniteIniValue $state.Text $definition.Section $definition.Key
    @{ Section = $definition.Section; Key = $definition.Key; Original = $original.Value; Applied = $definition.Value }
  })
  $backup = @{ Id = $id; Kind = 'fortnite'; Applied = $false; CreatedAt = [DateTime]::UtcNow.ToString('o'); Path = $state.Path; OriginalBytes = [Convert]::ToBase64String($state.Bytes); Values = $values }
  Save-Backup $backup $backupFile
  try {
    $updated = Set-FortniteIniValues $state.Text $values
    Write-FortniteIni $state $updated
    $backup.Applied = $true
    Save-Backup $backup $backupFile
  } catch {
    $failure = $_.Exception.Message
    try {
      Restore-FortniteAction $backup
      Remove-Item -LiteralPath $backupFile -Force -ErrorAction Stop
    } catch {
      throw ($failure + ' Original settings remain backed up; use recovery before retrying. ' + $_.Exception.Message)
    }
    throw $failure
  }
}
